﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        lblVehicleType = New Label()
        lblDays = New Label()
        lblDailyCharge = New Label()
        cboVehicleType = New ComboBox()
        lblTotalCost = New Label()
        txtDays = New TextBox()
        txtDailyCharge = New TextBox()
        txtTotalCost = New TextBox()
        btnCalculate = New Button()
        btnClear = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(242, 20)
        Label1.Name = "Label1"
        Label1.Size = New Size(317, 30)
        Label1.TabIndex = 0
        Label1.Text = "FAST LOGISTICS CAR RENTALS"
        ' 
        ' lblVehicleType
        ' 
        lblVehicleType.AutoSize = True
        lblVehicleType.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblVehicleType.Location = New Point(226, 73)
        lblVehicleType.Name = "lblVehicleType"
        lblVehicleType.Size = New Size(85, 17)
        lblVehicleType.TabIndex = 1
        lblVehicleType.Text = "Vehicle Type"
        ' 
        ' lblDays
        ' 
        lblDays.AutoSize = True
        lblDays.FlatStyle = FlatStyle.System
        lblDays.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDays.Location = New Point(188, 132)
        lblDays.Name = "lblDays"
        lblDays.Size = New Size(150, 17)
        lblDays.TabIndex = 2
        lblDays.Text = "Rental Duration (Days)"
        ' 
        ' lblDailyCharge
        ' 
        lblDailyCharge.AutoSize = True
        lblDailyCharge.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDailyCharge.Location = New Point(224, 204)
        lblDailyCharge.Name = "lblDailyCharge"
        lblDailyCharge.Size = New Size(87, 17)
        lblDailyCharge.TabIndex = 3
        lblDailyCharge.Text = "Daily Charge"
        ' 
        ' cboVehicleType
        ' 
        cboVehicleType.FormattingEnabled = True
        cboVehicleType.Location = New Point(371, 73)
        cboVehicleType.Name = "cboVehicleType"
        cboVehicleType.Size = New Size(166, 23)
        cboVehicleType.TabIndex = 4
        ' 
        ' lblTotalCost
        ' 
        lblTotalCost.AutoSize = True
        lblTotalCost.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotalCost.Location = New Point(241, 269)
        lblTotalCost.Name = "lblTotalCost"
        lblTotalCost.Size = New Size(70, 17)
        lblTotalCost.TabIndex = 5
        lblTotalCost.Text = "Total Cost"
        ' 
        ' txtDays
        ' 
        txtDays.Location = New Point(371, 131)
        txtDays.Name = "txtDays"
        txtDays.Size = New Size(166, 23)
        txtDays.TabIndex = 6
        ' 
        ' txtDailyCharge
        ' 
        txtDailyCharge.Location = New Point(371, 198)
        txtDailyCharge.Name = "txtDailyCharge"
        txtDailyCharge.Size = New Size(166, 23)
        txtDailyCharge.TabIndex = 7
        ' 
        ' txtTotalCost
        ' 
        txtTotalCost.Location = New Point(371, 263)
        txtTotalCost.Name = "txtTotalCost"
        txtTotalCost.Size = New Size(166, 23)
        txtTotalCost.TabIndex = 8
        ' 
        ' btnCalculate
        ' 
        btnCalculate.Font = New Font("Arial Black", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCalculate.Location = New Point(242, 314)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(96, 51)
        btnCalculate.TabIndex = 9
        btnCalculate.Text = "Calculate"
        btnCalculate.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(446, 314)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(91, 51)
        btnClear.TabIndex = 10
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(800, 450)
        Controls.Add(btnClear)
        Controls.Add(btnCalculate)
        Controls.Add(txtTotalCost)
        Controls.Add(txtDailyCharge)
        Controls.Add(txtDays)
        Controls.Add(lblTotalCost)
        Controls.Add(cboVehicleType)
        Controls.Add(lblDailyCharge)
        Controls.Add(lblDays)
        Controls.Add(lblVehicleType)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Form 1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lblVehicleType As Label
    Friend WithEvents lblDays As Label
    Friend WithEvents lblDailyCharge As Label
    Friend WithEvents cboVehicleType As ComboBox
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents txtDays As TextBox
    Friend WithEvents txtDailyCharge As TextBox
    Friend WithEvents txtTotalCost As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button

End Class
